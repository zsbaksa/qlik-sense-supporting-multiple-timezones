define(["qlik"],
    function(qlik, template) {
        return {
            template: template,
            support: {
                snapshot: true,
                export: true,
                exportData: false
            },
            paint: function() {
                let app = qlik.currApp(this);
                var ianaTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

                app.variable.setStringValue('vUserIANATimeZone', "='" + ianaTimeZone + "'");
            },
            controller: ['$scope', function($scope) {
            }]
        };
    }
);